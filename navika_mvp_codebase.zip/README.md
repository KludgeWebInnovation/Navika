# Navika MVP
Career assessment app with fox mascot.